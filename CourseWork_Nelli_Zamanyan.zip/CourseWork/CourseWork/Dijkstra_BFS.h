#pragma once
#include <vector>
#include <list>

class Graph	// class Graph definition
{
private:
	int number_of_vertices; // Graph's vetices number
	std::vector<std::vector<std::pair<int, int>>> adj_Dijkstra; // Vector of vertices, its adjacencies and edge lengths
	std::vector<std::vector<int>> adj_BFS;
	std::vector<int> distances;
public:
	Graph(int); // Constructor prototype
	void addEdgeDijkstra(int, int, int); // Method to add an edge/weight pair
	void addEdgeBFS(int, int);
	void printGraphDijkstra(); // Method to print vertices and its adjancency lists
	void printGraphBFS();
	void DijkstrasShortestPath(int); // Method to find the shortest paths
	void BFSshortestPath(int);
	void Dijkstra(Graph&);
	void BFS(Graph&);
};	// end class Graph
