#pragma once
template <class T>

class Node
{
	char Name_;
	int edge_len_;
	Node<T> *ptr_;
	Node (const char& Name, int edge_len, Node<T> *ptr = NULL) : Name_(Name), edge_len_(edge_len), ptr_(ptr) {}
};