#include "pch.h"
#include "Dijkstra_BFS.h"
#include <iostream>
#include <vector>
#include <queue>
#include <list>
#include <set>

#define INF 1000    // INFINITY

Graph::Graph(int number)    // Constructor implementation
{
	number_of_vertices = number; // Set number of vertices
	adj_Dijkstra.resize(number); // Resize Dijkstra's vector
	adj_BFS.resize(number); // Resize BFS's vector
	distances.resize(number);
	for (int i = 0; i < distances.size(); ++i)
	{
		distances[i] = -1;
	}
}

void Graph::addEdgeDijkstra(int vertex_1, int vertex_2, int weight)    // addEdgeDijkstra Method implementation
{
	adj_Dijkstra[vertex_1].push_back(std::make_pair(vertex_2, weight)); // Adds adj_BFS_Dijkstraacent vertex to adj_BFS_Dijkstraancency list
}

void Graph::addEdgeBFS(int vertex_1, int vertex_2)
{
	adj_BFS[vertex_1].push_back(vertex_2);
}

void Graph::printGraphDijkstra()  // printGraph Method implementation
{
	std::cout << " There are " << number_of_vertices << " Vertices in the Graph\n\n";
	std::cout << " *** List of Vertices ***" << "       *** adj_BFS_Dijkstraacencies ***\n";
	for (int v = 0; v < number_of_vertices; ++v)
	{
		std::cout << "\n adj_BFSacency list of Vertex " << v << ":   ";
		for (auto i = adj_Dijkstra[v].begin(); i != adj_Dijkstra[v].end(); ++i)  // Goes over adj_BFS_Dijkstraacency lists
		{
			std::cout << " --> " << (*i).first;  // Print the adj_BFS_Dijkstraacent vertex
		}
	}
	std::cout << "\n\n";
}

void Graph::DijkstrasShortestPath(int startVertex)  // Implementation of method shortestPath where 'vertex' is the initial point
{
	std::set<std::pair<int, int>> mySet;  // Creates a set to store vertices and their changed distances
	std::vector<int> distance(number_of_vertices, INF);  // Vector for distances. All paths are initialized to a large value
	mySet.insert(std::make_pair(0, startVertex));  // 0 is the distance and s is the initial point 
	distance[startVertex] = 0;  // Initializes distance of initial point to 0
	while (!mySet.empty())  // Continues until all shortest distances are finalized
	{
		std::pair<int, int> tmp = *(mySet.begin());  // Extracts the minimum distances
		mySet.erase(mySet.begin());  // Erases first element of set
		for (auto i = adj_Dijkstra[tmp.second].begin(); i != adj_Dijkstra[tmp.second].end(); ++i)  // Goes over the adj_BFS_Dijkstraacency list
		{
			if (tmp.first + (*i).second < distance[(*i).first])  // Checks if we found a shorter path to adj_BFS_Dijkstraacent vertex
			{
				if (distance[(*i).first] != INF)  // Checks if the value of distance of adj_BFS_Dijkstraacent vertex is not INFINITY
				{
					mySet.erase(std::make_pair(distance[(*i).first], (*i).first));  // Removes the current distance if it's int the set
				}
				distance[(*i).first] = tmp.first + (*i).second;  // Updates the new distance
				mySet.insert(std::make_pair(distance[(*i).first], (*i).first));  // Stores the vertex and new distance in the set
			}
		}
	}
	std::cout << " Minimum distances from vertex {" << startVertex << "} to other vertices " << '\n';
	for (int i = 0; i < number_of_vertices; ++i)
	{
		std::cout << " from {" << startVertex << "} to {" << i << "}: " << distance[i] << '\n';  // Prints distances 
	}
	std::cout << '\n';
}

void Graph::BFSshortestPath(int startVertex)

{
	std::queue<int> myQueue;
	std::cout << " We start from the vertex " << startVertex << ":\n\n";
	std::cout << " Output:  ";
	int q = 0;
	myQueue.push(startVertex);
	distances[startVertex] = q;
	while (!myQueue.empty())
	{
		for (int i = 0; i < adj_BFS[startVertex].size(); ++i)
		{
			q = distances[startVertex] + 1;
			if (distances[adj_BFS[startVertex][i]] == -1)
			{
				myQueue.push(adj_BFS[startVertex][i]);
				distances[adj_BFS[startVertex][i]] = q;
			}
		}

		std::cout << myQueue.front() << "  ";
		myQueue.pop();
		startVertex = myQueue.front();
	}
	std::cout << "\n\n distances:  ";
	for (int i = 0; i < distances.size(); ++i)
	{
		std::cout << "  " << distances[i];
	}
}

void Graph::Dijkstra(Graph& G)
{
	// Add edge 0
	G.addEdgeDijkstra(0, 1, 4);
	G.addEdgeDijkstra(0, 2, 3);
	G.addEdgeDijkstra(0, 4, 7);

	// Add edge 1
	G.addEdgeDijkstra(1, 0, 4);
	G.addEdgeDijkstra(1, 2, 6);
	G.addEdgeDijkstra(1, 3, 5);

	// Add edge 2
	G.addEdgeDijkstra(2, 0, 3);
	G.addEdgeDijkstra(2, 1, 6);
	G.addEdgeDijkstra(2, 3, 11);
	G.addEdgeDijkstra(2, 4, 8);

	// Add edge 3
	G.addEdgeDijkstra(3, 1, 5);
	G.addEdgeDijkstra(3, 2, 11);
	G.addEdgeDijkstra(3, 4, 2);
	G.addEdgeDijkstra(3, 5, 2);
	G.addEdgeDijkstra(3, 6, 10);

	// Add edge 4
	G.addEdgeDijkstra(4, 0, 7);
	G.addEdgeDijkstra(4, 2, 8);
	G.addEdgeDijkstra(4, 3, 2);
	G.addEdgeDijkstra(4, 6, 5);

	// Add edge 5
	G.addEdgeDijkstra(5, 3, 2);
	G.addEdgeDijkstra(5, 6, 3);

	// Add edge 6
	G.addEdgeDijkstra(6, 3, 10);
	G.addEdgeDijkstra(6, 4, 5);
	G.addEdgeDijkstra(6, 5, 3);

	G.printGraphDijkstra();
	std::cout << '\n';

	for (int i = 0; i < 7; ++i)
	{
		G.DijkstrasShortestPath(i);  // Calls function for each vertex to get all distances of all vertices
	}
}

void Graph::BFS(Graph& G)
{
	// Add edge 0
	G.addEdgeBFS(0, 1);
	G.addEdgeBFS(0, 2);
	G.addEdgeBFS(0, 4);

	// Add edge 1
	G.addEdgeBFS(1, 0);
	G.addEdgeBFS(1, 2);
	G.addEdgeBFS(1, 3);

	// Add edge 2
	G.addEdgeBFS(2, 0);
	G.addEdgeBFS(2, 1);
	G.addEdgeBFS(2, 3);
	G.addEdgeBFS(2, 4);

	// Add edge 3
	G.addEdgeBFS(3, 1);
	G.addEdgeBFS(3, 2);
	G.addEdgeBFS(3, 4);
	G.addEdgeBFS(3, 5);
	G.addEdgeBFS(3, 6);

	// Add edge 4
	G.addEdgeBFS(4, 0);
	G.addEdgeBFS(4, 2);
	G.addEdgeBFS(4, 3);
	G.addEdgeBFS(4, 6);

	// Add edge 5
	G.addEdgeBFS(5, 3);
	G.addEdgeBFS(5, 6);

	// Add edge 6
	G.addEdgeBFS(6, 3);
	G.addEdgeBFS(6, 4);
	G.addEdgeBFS(6, 5);
}

