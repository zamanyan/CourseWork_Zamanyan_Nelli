#include "Dijkstra_BFS.h"
#include <iostream>

int main()
{
	Graph G(7);
	int n;
	std::cout << " If your grap is weighted enter 1, else enter 2: ";
	std::cin >> n;
	if (n == 1)
	{
		G.Dijkstra(G);
		G.printGraphDijkstra();
		G.DijkstrasShortestPath(0);
	}
	else
	{
		G.BFS(G);
		G.printGraphBFS();
		G.BFSshortestPath(0);
	}
	return 0;
}

	
